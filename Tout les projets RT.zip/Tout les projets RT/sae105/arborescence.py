
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 13:27:35 2022

@author: e22010797
"""

import os 

"""ce script permet d'initialiser mon environnement de travail pour mon projet en y créant son arborescence"""

os.mkdir("SRC")
os.mkdir("SRC/Prog")
os.mkdir("SRC/Prog/Sae105")
os.mkdir("SRC/Prog/Sae105/Codes")
os.mkdir("SRC/Prog/Sae105/Resultats")
os.mkdir("SRC/Prog/Sae105/Donnees")
os.mkdir("SRC/Prog/Sae105/Donnees/Donnee_Brute")
os.mkdir("SRC/Prog/Sae105/Donnees/Donnee_pret")