def mots_fichier(nom_fichier):
    # Ouvrir le fichier en mode lecture
    with open(nom_fichier, 'r') as f:
        # Lire le contenu du fichier ligne par ligne
        lignes = f.readlines()

    # Initialiser une liste pour stocker les mots et leur nombre d'utilisation
    mots_utilises = []

    # Pour chaque ligne dans le fichier...
    for ligne in lignes:
        # ...découper la ligne en mots en utilisant les espaces comme séparateurs
        mots = ligne.split(' ')

        # Pour chaque mot dans la ligne...
        for mot in mots:
            # ...si le mot n'a pas encore été utilisé, l'ajouter à la liste des mots utilisés
            # avec un nombre d'utilisation de 1
            if mot not in mots_utilises:
                mots_utilises.append([mot, 1])
            # Sinon, incrémenter le nombre d'utilisation du mot dans la liste des mots utilisés
            else:
                for utilisation in mots_utilises:
                    if utilisation[0] == mot:
                        utilisation[1] += 1

    # Renvoyer la liste des mots utilisés et leur nombre d'utilisation
    return mots_utilises

def main():
  
    print (mots_fichier('fichier_0.txt'))
    
    
if __name__=='__main__':
    main()