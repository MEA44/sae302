# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 21:56:20 2022

@author: cewis
"""

import os
import string


def compte_lignes_mots(nom_fichier):
    """on définit une fonction qui compte le nombre de lgines et de mots dans
    un fichier, elle prendra en entrée le fichier et renverra le nombre de lignes
    et le nombre de mots"""
    
    with open(nom_fichier, 'r') as fd:  #lecture de l'ensemble des lignes dans une liste
        caractere_mots = string.ascii_letters + string.digits + '_' + 'éèêëàâäôòöùûüœîï'    #on définit les caractéres que l'on souhaite avoir dans notre liste
        format_line=[]  #on initie une liste vide
        line=0      #compteur
        compteurligne=0     #on initie un compteur de lignes à 0
        while line !='':    #tant que EOF n'est pas atteint on va dans la boucle
            line=fd.readline()  #on lit la ligne suivante 
            compteurligne+=1
            for i in line: 
                if i not in caractere_mots: #si le caractère ne fait pas partie de notre liste de caractères voulu alors
                    format_line.append(' ') #on rajoute un espace
                else: #sinon 
                    format_line.append(i) #on rajoute le caractère à notre liste
        e=''.join(format_line)
    liste=e.split()
    return (compteurligne), len(liste) #on return la taille des mots et des lignes
    


def compte_dans_fichiers(liste_fichier):
    txtfiles = ()
    liste = liste_fichier
    for i in range(len(liste)) :
        txtfiles+=compte_lignes_mots(liste[i])
    return txtfiles

def mots_fichier(nom_fichier):
    with open(nom_fichier, 'r') as f:
        
        lignes = f.readline()
        mots = string.ascii_letters + string.digits +  '_' + 'éèêëàâäôòöùûüœîï'  
        for ligne in lignes:
            ligne = ligne.rstrip('/n')
            
        mots_utilises = []
        
        for ligne in lignes:
            format_line = []
            
        for caractere in ligne:
            if caractere not in mots:
                format_line.append(' ')
            else:
                format_line.append(caractere)
        ligne = ''.join(format_line)
        
        ligne_formatee = ligne.split()
        
        for mot in ligne_formatee:
            
            if [mot, 1] not in mots_utilises:
                mots_utilises.append([mot, 1])
                
            else:
                for utilisation in mots_utilises:
                    if utilisation[0] == mot:
                        utilisation[1] += 1
    return mots_utilises
    
    
    
    
    
    
    
    
    
    


def main():
    """on effectue des test unitaires pour vérifier que la fonction marche"""
    # print(compte_lignes_mots("/amu'home/e22010797/toutlestxt/fichiers/fichier_1.txt"))
    liste_de_fichiers = [f'/amuhome/e22010797/toutlestxt/fichiers/fichier_{i}.txt' for i in range(50)]
    print(liste_de_fichiers)
    
    print(compte_dans_fichiers(liste_de_fichiers))
    
if __name__=='__main__':
    main()
